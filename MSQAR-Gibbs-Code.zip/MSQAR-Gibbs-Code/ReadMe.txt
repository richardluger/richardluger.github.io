###########################################################################################################################################
###########################################################################################################################################

Data and code files accompanying “Markov-switching quantile autoregression: a Gibbs sampling approach” by Xiaochun Liu and Richard Luger

###########################################################################################################################################
###########################################################################################################################################



1. “QuarterlyRealInterestRate.txt” contains the data on the quarterly real interest rate.



2. “MSQAR.r” is an R program that estimates the unconstrained MSQAR(3,3) model (3 regimes and 3 lags) and also computes the associated marginal likelihood. The code can easily be modified to accommodate a different number of regimes and/or lags. 


 
3. “MSQAR_Constrained.r” is an R program that estimates the non-crossing MSQAR(3,3) model. Specifically, given a previously estimated MSQAR(3,3) at quantile level tau_{j-1}, the program estimates the MSQAR(3,3) model at quantile level tau_j so that the conditional quantiles at level tau_j don’t cross those at level tau_{j-1}. 

For example, if you run the program “MSQAR.r” as is, it will estimate the MSQAR(3,3) at quantile level tau=0.5 (the conditional median). The estimation results are written to the file “outputfile.txt” and these serve as inputs for the subsequent step. 

If you then run the program “MSQAR_Constrained.r” it will estimate the MSQAR(3,3) at quantile level tau=0.4 such that the conditional quantiles do no cross those at the previous quantile level (tau=0.5). 


The program “MSQAR_Constrained.r” can then be used repeatedly (with tau set in turn to 0.3, 0.2, 0.1) to obtain the non-crossing quantiles at levels tau=0.3, 0.2, 0.1. 

Similarly, run “MSQAR.r” with the setting tau=0.5, and then run “MSQAR_Constrained.r” repeatedly (with tau set in turn to 0.6, 0.7, 0.8, 0.9) to obtain the non-crossing quantiles at levels tau=0.6, 0.7, 0.8, and 0.9.










   












 

