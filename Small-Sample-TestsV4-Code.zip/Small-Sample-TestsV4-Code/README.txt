#################################################################################################################################

Gungor-Luger: "Small-sample tests for stock return predictability with possibly non-stationary regressors and GARCH-type effects"

#################################################################################################################################


 	Table9.R		# Replicates the results in Table 9

	Fct_newtests.R     	# Function that computes the new tests


READ ME: 

These codes (written in R) reproduce the empirical results in Table 9 for the full 67-year sample period. 

In order to replicate the results for the subperiods, go into the file "Table9.R" and change the sample period in the section marked as "Choose the sample period." 



If you have any questions, please contact Richard Luger <richard.luger@fsa.ulaval.ca>
























