#############################################################################################
# Function that computes the new sign and signed-ramk tests
#############################################################################################


newtests <- function(bb, twosided, totsim){			# ( twosided=FALSE ) --->  right-sided tests;	 ( twosided=TRUE ) ---> two-sided tests

	S <- matrix(0,N,1)
	W <- matrix(0,N,1)

	mW <- TT*(TT+1)/4
	vW <- TT*(TT+1)*(2*TT+1)/24

	ranks <- matrix(rank(abs(yy-bb)),TT,1)

	for (i in 1:N){
		S[i] <- sum( sign01( (yy-bb)*xx[,i] ) )
		S[i] <- ( S[i] - TT/2 )/sqrt(TT/4)

		W[i] <- sum( sign01( (yy-bb)*xx[,i] )*ranks )
		W[i] <- ( W[i] - mW )/sqrt(vW)
	}

	if (twosided==FALSE) pvals <- 1-pnorm(S)               # right-sided p-values
	if (twosided==TRUE)  pvals <- 2*( 1-pnorm(abs(S)) )    # two-sided p-values

	Smin <- 1-min(pvals)
	Sprod <- 1-prod(pvals)
	Spvals <- pvals
  	
	if (twosided==FALSE) pvals <- 1-pnorm(W)               # right-sided p-values
	if (twosided==TRUE)  pvals <- 2*( 1-pnorm(abs(W)) )    # two-sided p-values

	Wmin <- 1-min(pvals)
	Wprod <- 1-prod(pvals)
  	Wpvals <- pvals

	stats <- matrix(0, totsim, 4)
	stats[totsim,1] <- Smin
	stats[totsim,2] <- Sprod
	stats[totsim,3] <- Wmin
	stats[totsim,4] <- Wprod

	for (isim in 1:(totsim-1)){

			yysim <- rnorm(TT)

			S <- matrix(0,N,1)
			W <- matrix(0,N,1)

			for (i in 1:N){
				S[i] <- sum( sign01( yysim * xx[,i] ) )
				S[i] <- ( S[i] - TT/2 )/sqrt(TT/4)

				W[i] <- sum( sign01( yysim * xx[,i] )*ranks )
				W[i] <- ( W[i] - mW )/sqrt(vW)
			}

			if (twosided==FALSE) pvals <- 1-pnorm(S)         		# right-sided p-values
			if (twosided==TRUE)  pvals <- 2*( 1-pnorm(abs(S)) )    	# two-sided p-values

			Smin <- 1-min(pvals)
			Sprod <- 1-prod(pvals)

			if (twosided==FALSE) pvals <- 1-pnorm(W)         		# right-sided p-values
			if (twosided==TRUE)  pvals <- 2*( 1-pnorm(abs(W)) )    	# two-sided p-values

			Wmin <- 1-min(pvals)
			Wprod <- 1-prod(pvals)
      
			stats[isim,1] <- Smin
			stats[isim,2] <- Sprod

			stats[isim,3] <- Wmin
			stats[isim,4] <- Wprod
			
		}

		u <- runif(totsim)

	    temp <- ranklex(stats[,1],u)
	    pvalue1 <- (totsim - temp + 1)/totsim

	    temp <- ranklex(stats[,2],u)
	    pvalue2 <- (totsim - temp + 1)/totsim

	    temp <- ranklex(stats[,3],u)
	    pvalue3 <- (totsim - temp + 1)/totsim

   	    temp <- ranklex(stats[,4],u)
	    pvalue4 <- (totsim - temp + 1)/totsim

		return(c(pvalue1,pvalue2,pvalue3,pvalue4))

}



