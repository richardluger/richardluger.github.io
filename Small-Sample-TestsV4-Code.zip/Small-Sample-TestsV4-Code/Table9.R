###############################################################################################################################################################
# Code to reproduce Table 9 of Gungor-Luger "Small-sample tests for stock return predictability with possibly non-stationary regressors and GARCH-type effects"
###############################################################################################################################################################

	rm(list=ls())  						# Clear the workspace

###############################################################################################################################################################
# Functions used
###############################################################################################################################################################
  
	ranklex <- function(x,uu) {			# Function that computes the lexicographic rank
		n  <- length(x)
		vv <- cbind(x,uu)
		r  <- matrix(0, n-1, 1)
		stat <- vv[n,]
		r[ stat[1] > vv[1:(n-1),1] ] <- 1
		r[ (stat[1] == vv[1:(n-1),1]) & (stat[2] > vv[1:(n-1),2]) ] <- 1
		sum(r)+1
	}


	sign01 <- function(z){				# Sign function
		z <- matrix(z,length(z),1)
		return(as.numeric(z >= 0))
	}
	
	
 	source("Fct_newtests.R")      		# Function that computes the new tests
	
###############################################################################################################################################################
# Data
###############################################################################################################################################################

  	dataset <- read.table("DataSet_Jan1948_Dec2014.txt")

  	dates    <- dataset$V1
  	xret     <- dataset$V2       # excess returns
  	dp       <- dataset$V3       # log dividend/price
  	ep       <- dataset$V4       # log earnings/price
  	bm       <- dataset$V5       # book-to-market
  	dfy      <- dataset$V6       # default yield
  	tms      <- dataset$V7       # term spread
  	tbl      <- dataset$V8       # short rate

  	Tsize    <- length(dates)

###############################################################################################################################################################
# Choose the sample period, i.e. full sample period, 20-year subperiods, 10-year subperiods
###############################################################################################################################################################

# Full sample
# Jan 1948 -- Dec 2014
   	Tbegin <-   1                 #   <----- Beginning of the period
	Tend <-   Tsize               #   <----- End of the period



# 10-year subperiods

# Jan 1948 -- Dec 1957
#  Tbegin <- 1
#  Tend <- 120

# Jan 1958 -- Dec 1967
#  Tbegin <- 121
#  Tend <- 240

# Jan 1968 -- Dec 1977
# Tbegin <- 241
# Tend <- 360

# Jan 1978 -- Dec 1987
#  Tbegin <- 361
#  Tend <- 480

# Jan 1988 -- Dec 1997
#  Tbegin <- 481
#  Tend <- 600

# Jan 1998 -- Dec 2007
#  Tbegin <- 601
#  Tend <- 720

# Jan 2008 -- Dec 2014
#  Tbegin <- 721
#  Tend <- Tsize



# 20-year subperiods

# Jan 1948 -- Dec 1967
#  Tbegin <- 1
#  Tend <- 240

# Jan 1968 -- Dec 1987
#  Tbegin <- 241
#  Tend <- 480

# Jan 1988 -- Dec 2014
#  Tbegin <- 481
#  Tend <- Tsize



   	mtt <- Tend - Tbegin + 1


   	xret   <- xret[Tbegin:Tend]
   	dp     <- dp[Tbegin:Tend]
   	ep     <- ep[Tbegin:Tend]
   	bm     <- bm[Tbegin:Tend]
   	dfy    <- dfy[Tbegin:Tend]
   	tms    <- tms[Tbegin:Tend]
   	tbl    <- tbl[Tbegin:Tend]
  
  	Tsize <- mtt                   # Number of time-series observations
  	N     <- 6                     # Number of predictors

  # Select the variables

  	rDATA <- xret
  	xDATA <- cbind(dp, ep, bm, dfy, tms, tbl)
 

	set.seed(123456)



###############################################################################################################################################################
# Estimation of predictive regression by OLS under the alternative for Wald test
###############################################################################################################################################################

	y <- rDATA       # <------ in the application: stock returns (from 1 to Tsize) go here
	x <- xDATA       # <------ in the application: predictors (from 1 to Tsize) go here

	yy   <- y[2:Tsize]
	ones <- matrix(1, Tsize-1, 1)
	xx   <- cbind(ones, x[ 1 : (Tsize-1),  ])

	betahat <- solve( t(xx) %*% xx) %*% t(xx) %*% yy
	ehat <- yy - xx %*% betahat

	varehat <- t(ehat)%*%ehat/(dim(xx)[1])

	varbetahat <- solve( t(xx) %*% xx) * matrix(varehat,(N+1),(N+1))
	Wald <- betahat[2:(N+1)] %*% solve(varbetahat[2:(N+1),2:(N+1)]) %*% betahat[2:(N+1)]

	OLSalphahatH1 <- betahat[1]
	OLSbetahatH1 <- betahat[2:(N+1)]

	OLSerrorshatH1     <- matrix(0,(Tsize-1),(N+1))
	OLSerrorshatH1[,1] <- ehat


	Wald_pvalue <- 1- pchisq(Wald, df=N)



###############################################################################################################################################################
# Sign and signed rank tests
###############################################################################################################################################################
   
	xmeds <- matrix(0,Tsize,N)							# recursive calculation of the median for each predictor
	for (t in 2:Tsize){
		for (i in 1:N){
			xmeds[t,i] <- median(x[1:t,i])
		}
	}

	xdev <- x - xmeds									# deviations of predictors from their recursive medians


	TT <- Tsize-1										# effective sample size

	xx <- as.matrix(xdev[1:TT,])
        
    
	################################
	# Procedures based on the median
	################################

	medhat <- median(yy)

	pvalues <- newtests(bb=medhat,twosided=TRUE,totsim=100)

	alpha <- 0.05
	SminMED_pvalue <- pvalues[1]
	SprodMED_pvalue <- pvalues[2]
	WminMED_pvalue <- pvalues[3]
	WprodMED_pvalue <- pvalues[4]


	#####################################################
	# Proceduress based on first-step confidence interval
	#####################################################

	alpha1 <- 0.01
	alpha2 <- 0.04

    crit1 <- qnorm(1-alpha1/2)

    temp <- sort(yy)
    k1 <- ceiling(TT/2 - sqrt(TT/4)*crit1)
    k2 <- floor(TT/2 + sqrt(TT/4)*crit1)

    fine <- 0.0001

    CI <- seq(temp[k1],temp[k2],fine)
   
    pvalues <- matrix(0,length(CI),4)

    j <- 1
	for (bb in CI){

		pvalues[j,] <- newtests(bb, twosided= TRUE, totsim=100)

		j <- j + 1
	}

	pmax <- max(pvalues[,1])
	SminCI_pvalue <- pmax


	pmax <- max(pvalues[,2])
    SprodCI_pvalue <- pmax


	totWalsh <- TT*(TT+1)/2
	Walsh <- matrix(0, totWalsh, 1)
	k <- 1
	for (i in 1:TT){
		for (j in 1:i){
			Walsh[k] <- ( yy[i]+yy[j] )/2
			k <- k+1
		}
	}

	mW <- TT*(TT+1)/4
	vW <- TT*(TT+1)*(2*TT+1)/24

	a <- ceiling(mW - crit1*sqrt( vW ) )
	temp <- sort(Walsh)
    CI <- seq(temp[a+1],temp[totWalsh-a],fine)

    pvalues <- matrix(0,length(CI),4)
    j <- 1
	for (bb in CI){

		pvalues[j,] <- newtests(bb, twosided= TRUE, totsim=100)

		j <- j + 1
	}

	pmax <- max(pvalues[,3])
    WminCI_pvalue <- pmax


	pmax <- max(pvalues[,4])
    WprodCI_pvalue <- pmax



###############################################################################################################################################################
# Print p-values
###############################################################################################################################################################

print(c('T = ', Tsize, 'N = ', N))

print(c('Smin.med p-value', SminMED_pvalue))
print(c('Sprod.med p-value', SprodMED_pvalue))

print(c('Wmin.med p-value', WminMED_pvalue))
print(c('Wprod.med p-value', WprodMED_pvalue))

print(c('Smin p-value', SminCI_pvalue))
print(c('Sprod p-value', SprodCI_pvalue))

print(c('Wmin p-value', WminCI_pvalue))
print(c('Wprod p-value', WprodCI_pvalue))

print(c('Wald p-value', Wald_pvalue))










