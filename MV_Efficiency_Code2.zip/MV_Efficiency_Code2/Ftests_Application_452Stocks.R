rm(list=ls())   


ranklex <- function(x,uu) {
	n  <- length(x)
	vv <- cbind(x,uu) 
	r  <- matrix(0, nr=n, nc=1)
	for (i in 1:(n-1)){
	    if (vv[n,1] > vv[i,1]){
    	  r[i] <- 1     
	    }
	    if ((vv[n,1] == vv[i,1]) & (vv[n,2] > vv[i,2])) {
    	 r[i] <- 1   
		}
	}
	sum(r)+1
}



	stckdata     <- read.table("MONTHLY_NYSE_AMEX_NASDAQ.txt")
	datee        <- stckdata$V1
	stck_temp    <- data.frame(as.matrix(stckdata[,2:453]))
	stck         <- stck_temp*100                           # Returns in percentage

	factors_data <- read.table("MONTHLY_FACTORS.txt")
	mkt          <- factors_data$V2
	smb          <- factors_data$V3
	hml          <- factors_data$V4
	mom          <- factors_data$V5
	rff          <- factors_data$V6

	tt           <- length(mkt)
	B            <- 1
	E            <- tt
	TT           <- E - B + 1              # Number of time series  = 468
	N            <- length(stck[1,])       # Number of test assets  = 452
	K            <- 1                      # Number of pricing factors (K = 1 for CAPM, K=3 for FF)
	totsim       <- 500


	x1 <- matrix(mkt[B:E],TT,1)                # Factors
	x2 <- matrix(smb[B:E],TT,1)
	x3 <- matrix(hml[B:E],TT,1)
	x4 <- matrix(mom[B:E],TT,1)
	rff <- matrix(rff[B:E],TT,1)


	Ytemp <- stck[B:E,]
	Y     <- matrix(0,TT,N)

	for (vv in 1:N){
		Y[,vv]    <- Ytemp[,vv] - rff            # Excess return on test assets
	}

	ones <- matrix(1,TT,1)
	factors <- matrix(cbind(x1, x2, x3,x4),TT,4)

	X    <- matrix(factors[,1:K],TT,K)
	XX   <- matrix(cbind(ones, X),TT,(K+1))


 
	# OLS parameter estimates


	Xtemp    <- solve( t(XX) %*% XX)

    Bhat1 <- Xtemp %*% t(XX) %*% Y

    Ehat1 <- Y - XX %*% Bhat1         # Unrestricted
    SSRu <- t(Ehat1) %*% Ehat1
    SigmaU <- SSRu / TT


    H         <- matrix(0,1,K+1)
    H[1,1]    <- 1
    C <- matrix(0,1,N)

    Bhat0 <- Bhat1 - Xtemp %*% t(H) %*% solve( H %*% Xtemp %*% t(H) ) %*% (H %*% Bhat1 - C )		# Restricted
    Ehat0 <- Y - XX %*% Bhat0
    SSRr <- t(Ehat0) %*% Ehat0
    SigmaR <- SSRr / TT

               
     # GRS test
     

	if ((TT - K - N) >= 1 ) {
		ahat      <- Bhat1[1,]
    	shat      <- SigmaU
    
	    fact     <- t(X)
	    mufactor     <- matrix(0,K,1)
	    ssqm_temp    <- matrix(0, TT, K)

	    for (i in 1:K){
	      mufactor[i]     <- (1/TT)*sum(X[,i])
	      ssqm_temp[,i]   <- X[,i]-mufactor[i]
   	 	}
    	
	   ssqm <-  1/TT*( t(ssqm_temp)%*%ssqm_temp )
    
	   GRS       <- ((TT-N-K)/N)*solve(1+( t(mufactor) %*% solve(ssqm) %*% mufactor ))*(t(ahat)%*%solve(shat)%*%ahat)
	   pval_GRS  <-  1-pf(GRS,N,(TT-N-K))
	}
     
      
 	# Pesaran-Yamagata tests


	v <- TT - K - 1

	t2 <- matrix(0, N, 1)

	eye <- matrix(0, TT, TT)
	diag(eye) <- 1

    MX <- eye - X %*% solve( t(X) %*% X ) %*% t(X)

	num <- matrix( (t(ones) %*% MX %*% ones) * v, N, 1)

    t2 <- (Bhat1[1,]^2) * num / ( TT * diag(SigmaU) )

    pN <- 0.05/(N-1)
    thetaN <- qnorm( 1-pN/2 )^2
    rhobar <- 0
    for ( i in 2 : N ){
    	for ( j in 1 : (i-1) ){
    		temp <- SigmaU[i,j] / sqrt( SigmaU[i,i] * SigmaU[j,j] )
    		temp2 <- temp^2
    		if ( v*temp2 >= thetaN){
    			rhobar <- rhobar + temp2
    		}
    	}
    }
    rhobar <- rhobar * 2 / ( N * ( N - 1 ) )

    Jalpha2 <- sum(t2 - v/(v-2))/sqrt(N)

    den <- ( v/ (v-2) ) * sqrt( 2 * (v-1) * (1 + (N-1)*rhobar)  / (v-4) )
    Jalpha2 <- Jalpha2 / den

    pval_Jalpha2 <- 1-pnorm(Jalpha2)

	    
	## MC Fmax tests

    
    temp <-  (diag(SSRr) - diag(SSRu) )/( diag(SSRu)  )            
    Fmax  <- max( temp )  
    Fmax_actual  <- Fmax 	# Gives the Fmax from the actual (not simulated) sample
    
    LMCstats <- matrix(0,totsim,1)
    LMCstats[totsim] <- Fmax

    BMCstats <- matrix(0,totsim,1)
    BMCstats[totsim,1] <- Fmax 

	Ehat0data <- Ehat0   
	Bhat0data <- Bhat0     
	
	set.seed(123456)
	                  
    for (isim in 1:(totsim-1)){
      
		esim <- sign(rnorm(TT)) * Ehat0data
   
		Ysim <-  XX %*% Bhat0data +  esim
                      
  	    Y <- Ysim
  	    
	    Bhat1 <- Xtemp %*% t(XX) %*% Y    
	    Ehat1 <- Y - XX %*% Bhat1
	    SSRu <- t(Ehat1) %*% Ehat1
    		    
	    Bhat0 <- Bhat1 - Xtemp %*% t(H) %*% solve( H %*% Xtemp %*% t(H) ) %*% (H %*% Bhat1 - C )
	    Ehat0 <- Y - XX %*% Bhat0
	    SSRr <- t(Ehat0) %*% Ehat0
		    		    			
		# LMC test		    		  		    

	    temp <- (diag(SSRr) - diag(SSRu) )/( diag(SSRu)  )                        
	    Fmax  <- max( temp )		    		       		    		    	    	    	    
        LMCstats[isim] <- Fmax	            

		# BMC test
		
		SSRr <- t(esim) %*% esim
		temp <- (diag(SSRr) - diag(SSRu) )/( diag(SSRu)  )                                                          
		Fmax  <- max( temp )				    		    		                		 		                	    		             		                	    
	    BMCstats[isim] <- Fmax
	                      	    	    	
	}    	
	    
    uu <- runif(totsim)
        
    temp <- ranklex(LMCstats,uu) 
   	LMCpvalueFmax <- (totsim - temp + 1)/totsim
  	    
    temp <- ranklex(BMCstats,uu) 
    BMCpvalueFmax <- (totsim - temp + 1)/totsim    
   

	print('============================================')

	print(c('Period =', datee[B],'to', datee[E], 'Nsize =', N, 'Ksize =', K))

	print('============================================')

	if ((TT - K - N) >= 1 ) {
		print(c('GRS        =', GRS))
		print(c('p-value    =', pval_GRS))
	}

	print('============================================')

	print(c('Jalpha2    =',Jalpha2))
	print(c('p-value    =', pval_Jalpha2))

	print('============================================')

	print('F-Max')
	print(c('------','F-max           =', Fmax_actual))

	if (LMCpvalueFmax > 0.05 ) {
		print(c('ACCEPT ----------','LMCp-value       =', LMCpvalueFmax))
	}

	if (BMCpvalueFmax <= 0.05 ) {
		print(c('REJECT ----------','BMC p-value      =', BMCpvalueFmax))
	}

	if ( (LMCpvalueFmax <= 0.05 ) & (BMCpvalueFmax > 0.05 ) ) {
		print(c('INCONCLUSIVE ----','LMC p-value      =', LMCpvalueFmax))
		print(c('INCONCLUSIVE ----','BMC p-value      =', BMCpvalueFmax))
	}




