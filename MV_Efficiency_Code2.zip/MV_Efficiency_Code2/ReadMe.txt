############################################################################################################################################################################################
############################################################################################################################################################################################

Data and code files accompanying “Multivariate tests of mean-variance efficiency and spanning with a large number of assets and time-varying covariances” by Sermin Gungor and Richard Luger

############################################################################################################################################################################################
############################################################################################################################################################################################

Run these R codes to replicate the empirical results in Table 4 (Ftests_Application_452Stocks.R) and Table 5 (Stests_Application_452Stocks.R). 

The codes are straightforward as they closely follow the descriptions in the paper. 

* Be patient because the codes set [totsim <- 500] meaning there are 499 Monte Carlo replications. 

** If you have any questions, please contact Richard Luger by email: richard.luger@fsa.ulaval.ca 
















