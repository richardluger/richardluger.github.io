rm(list=ls())   


ranklex <- function(x,uu) {
	n  <- length(x)
	vv <- cbind(x,uu) 
	r  <- matrix(0, nr=n, nc=1)
	for (i in 1:(n-1)){
	    if (vv[n,1] > vv[i,1]){
    	  r[i] <- 1     
	    }
	    if ((vv[n,1] == vv[i,1]) & (vv[n,2] > vv[i,2])) {
    	 r[i] <- 1   
		}
	}
	sum(r)+1
}



   stckdata     <- read.table("MONTHLY_NYSE_AMEX_NASDAQ.txt")
   datee        <- stckdata$V1
   stck_temp    <- data.frame(as.matrix(stckdata[,2:453]))
   stck         <- stck_temp#*100                           # Returns in percentage

   factors_data <- read.table("MONTHLY_FACTORS.txt")
   mkt          <- factors_data$V2           # Market return in excess of the risk free rate
   smb          <- factors_data$V3
   hml          <- factors_data$V4
   mom          <- factors_data$V5
   rff          <- factors_data$V6

   tt           <- length(mkt)
   B            <- 1
   E            <- tt
   TT           <- E - B + 1                    # Number of Time-Series  = 468
#   N            <- length(stck[1,1:188])       # Number of test assets  = 188
   N            <- length(stck[1,])             # Number of test assets  = 452
   K            <- 3                            # Number of pricing factors
   totsim       <- 500


   x1 <- matrix(mkt[B:E]/100,TT,1)               # Factors
   x2 <- matrix(smb[B:E]/100,TT,1)
   x3 <- matrix(hml[B:E]/100,TT,1)
   x4 <- matrix(mom[B:E]/100,TT,1)
   rff <- matrix(rff[B:E]/100,TT,1)
   x1  <- x1 + rff                           	# Market return


   Ytemp <- stck[B:E,]
   Y     <- matrix(0,TT,N)

   for (vv in 1:N){
 	 Y[,vv]    <- Ytemp[,vv]                    # Raw return on test assets
   }

   ones <- matrix(1,TT,1)
   factors <- matrix(cbind(x1, x2, x3,x4),TT,4)

   X    <- matrix(factors[,1:K],TT,K)
   XX   <- matrix(cbind(ones, X),TT,(K+1))




   # OLS parameter estimates

    Xtemp    <- solve( t(XX) %*% XX)

    Bhat1 <- Xtemp %*% t(XX) %*% Y


    Ehat1 <- Y - XX %*% Bhat1         # Unrestricted
    SSRu <- t(Ehat1) %*% Ehat1
    SigmaU <- SSRu / TT


    H         <- matrix(0,2,K+1)
    H[1,1]    <- 1
    H[2,2:(K+1)] <- 1
    C <- matrix(0,2,N)
    C[2,]  <- 1

    Bhat0 <- Bhat1 - Xtemp %*% t(H) %*% solve( H %*% Xtemp %*% t(H) ) %*% (H %*% Bhat1 - C )   # Restricted
    Ehat0 <- Y - XX %*% Bhat0
    SSRr <- t(Ehat0) %*% Ehat0
    SigmaR <- SSRr / TT


   ## HK test

   if (TRUE){
   
	    A  <- 100   # Rescaling scalar: This takes care of the overflow during the numerical computation of the determinant
     
	    if (2*(TT - K - N) >= 1 ) {
    	    UU <- det(SigmaR*A)/det(SigmaU*A)        
	    	HK <- (TT - K - N)*(1/N)* (sqrt(UU) - 1)
	    	pval_HK <- 1- pf(HK, 2*N, 2*(TT - K - N) )
    	}            
  	}  
  

	## New MC tests
    
    temp <-  (diag(SSRr) - diag(SSRu) )/( diag(SSRu)  )      
    Fmax  <- max( temp ) 
    
    Fmax_actual  <- Fmax # Gives the Fmax stat from the actual (not simulated) sample
                
    LMCstats <- matrix(0,totsim,1)
    LMCstats[totsim] <- Fmax

    BMCstats <- matrix(0,totsim,1)
    BMCstats[totsim] <- Fmax 

	Ehat0data <- Ehat0   
	Bhat0data <- Bhat0    
	
	set.seed(123456) 
              
    for (isim in 1:(totsim-1)){
   
		esim <- sign(rnorm(TT)) * Ehat0data
   
		Ysim <-  XX %*% Bhat0data +  esim
                      
  	    Y <- Ysim
  	    
	    Bhat1 <- Xtemp %*% t(XX) %*% Y    
	    Ehat1 <- Y - XX %*% Bhat1
	    SSRu <- t(Ehat1) %*% Ehat1
    		    
	    Bhat0 <- Bhat1 - Xtemp %*% t(H) %*% solve( H %*% Xtemp %*% t(H) ) %*% (H %*% Bhat1 - C )
	    Ehat0 <- Y - XX %*% Bhat0
	    SSRr <- t(Ehat0) %*% Ehat0
		    		    
		# LMC test	
	    		  		    
	    temp <- (diag(SSRr) - diag(SSRu) )/( diag(SSRu)  )                         
	    Fmax  <- max( temp )                   		    	    	    	    
        LMCstats[isim] <- Fmax	            

		# BMC test

	    SSRr <- t(esim) %*% esim		    		    		                		  
	    temp <- (diag(SSRr) - diag(SSRu) )/( diag(SSRu)  )                        
	    Fmax  <- max( temp )        	                	    		             		                	   
        BMCstats[isim] <- Fmax
	                      	    	    	
    }    	
	    	   	    	    	    
	uu <- runif(totsim)
        
    temp <- ranklex(LMCstats,uu) 
   	LMCpvalueFmax <- (totsim - temp + 1)/totsim
  	    
    temp <- ranklex(BMCstats,uu) 
    BMCpvalueFmax <- (totsim - temp + 1)/totsim    


print('============================================')
print('============================================')


print(c('Period=',datee[B],'--' ,datee[E],'Nsize=',N, 'Ksize=',K))


print('============================================')
print('============================================')

if (2*(TT - K - N) >= 1 ) {
	print(c('HK      =',HK))
	print(c('p-value  =', pval_HK))
}


print('============================================')
print('============================================')

print('F-Max')
print(c('------','F-max           =',Fmax_actual))

if (LMCpvalueFmax > 0.05 ) {
	print(c('ACCEPT ----','LMCp-value       =', LMCpvalueFmax))
}

if (BMCpvalueFmax <= 0.05 ) {
	print(c('REJECT ----','BMC p-value      =', BMCpvalueFmax))
}

if ( (LMCpvalueFmax <= 0.05 ) & (BMCpvalueFmax > 0.05 ) ) {
	print(c('INCONCLUSIVE ----','LMC p-value      =', LMCpvalueFmax))
	print(c('INCONCLUSIVE ----','BMC p-value      =', BMCpvalueFmax))
}

