#**********************************************************************************
#   "Exact Inference in Long-Horizon Predictive Quantile Regressions with an Application to Stock Returns"
#    Journal of Financial Econometrics

# (C) Sermin Gungor (UWO  and Bank of Canada) and Richard Luger (Laval University)
#     sgungor@uwo.ca & richard.luger@fsa.ulaval.ca

#**********************************************************************************

# Description:
#   File: Table9_AR_Estimates_Weekly     
#   This code produces the AR(1) estimates
#   Period: Jan 1962 -- Dec 2015

#**********************************************************************************;


rm(list=ls())  
library(MASS)  
library(mvtnorm)
library(quantreg)


#########################################################################################################################################################

##############################################################
#   DATA
##############################################################


  dataa <- read.table("Data_Used_Weekly_Jan1962_Dec2015.csv", header = TRUE, sep = ",")      # Data Period: Jan 1962 -- Dec 2015)

  datee    <- dataa$Dates
  xret     <- dataa$Xret_SPvw   # excess returns
  logxret  <- log(xret + 1)   	# log excess returns
  dp       <- dataa$d.p       	# log dividend/price
  ep       <- dataa$e.p       	# log earnings/price
  bm       <- dataa$b.m       	# book-to-market
  dfy      <- dataa$dfy       	# default yield
  tms      <- dataa$tms       	# term spread
  tbl      <- dataa$tbl       	# short rate


  tt    <- length(datee)
  Tsize <- tt
  N     <- 6

  
  superXDATA <- cbind(dp, ep, bm, dfy, tms, tbl)
  numVars  <- length(superXDATA[1,])


  phihatDATALAD <- matrix(0,numVars,1)
  phihatstdevDATALAD  <- matrix(0,numVars,1)


  for (l in 1:numVars) {

	x <- superXDATA[1:Tsize,l]

	#########################################################################################################################################################
	## LAD regression for predictor variable

	YY <- matrix( x[2:Tsize], Tsize-1, 1)
	X  <- matrix( x[1:(Tsize-1)], Tsize-1, 1)
   	
	temp <- rq(YY~X,tau=0.5)				
	phihatLAD <- as.numeric( summary(temp, se="iid")$coef[,"Value"][2] )	
	vhatLAD   <- as.numeric( summary(temp, se="iid")$coef[,"Std. Error"][2] )^2			

	phihatDATALAD[l]        <- phihatLAD
	phihatstdevDATALAD[l]   <-  as.numeric( summary(temp, se="iid")$coef[,"Std. Error"][2] )

  }

  
  print("--------LAD")

  print(t(cbind(round(phihatDATALAD, digits=3), round(phihatstdevDATALAD, digits = 3))))

















