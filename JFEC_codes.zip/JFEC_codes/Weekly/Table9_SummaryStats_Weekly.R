#**********************************************************************************
#   "Exact Inference in Long-Horizon Predictive Quantile Regressions with an Application to Stock Returns"
#    Journal of Financial Econometrics

# (C) Sermin Gungor (UWO  and Bank of Canada) and Richard Luger (Laval University)
#     sgungor@uwo.ca & richard.luger@fsa.ulaval.ca

#**********************************************************************************

# Description:
#   File: Table9_SummaryStats (Panel B)       
#   This code produces the summary statistics with monthly data
#   Period: Jan 1962 -- Dec 2015

#**********************************************************************************;


rm(list=ls())  ## clear the workspace

library(tseries)
library(moments)
library(quantreg)


##############################################################
#   DATA
##############################################################


  dataa <- read.table("Data_Used_Weekly_Jan1962_Dec2015.csv", header = TRUE, sep = ",")      # Data Period: Jan 1962 -- Dec 2015)

  datee    <- dataa$Dates
  xret     <- dataa$Xret_SPvw   # excess returns
  logxret  <- log(xret + 1)  	# log excess returns
  dp       <- dataa$d.p      	# log dividend/price
  ep       <- dataa$e.p       	# log earnings/price
  bm       <- dataa$b.m       	# book-to-market
  dfy      <- dataa$dfy       	# default yield
  tms      <- dataa$tms       	# term spread
  tbl      <- dataa$tbl       	# short rate

  
  tt    <- length(datee)
  Tsize <- tt
  N     <- 6

 
 #*****************************************************************************
  # Summary Statistics

  vars         <- cbind(xret, dp, ep, bm, dfy, tms, tbl)     # Variables
  meanvars     <- matrix(0,(N+1),1)
  medianvars   <- matrix(0,(N+1),1)
  sdvars       <- matrix(0,(N+1),1)
  skewvars     <- matrix(0,(N+1),1)
  kurtvars     <- matrix(0,(N+1),1)
  autocorrvars <- matrix(0,(N+1),1)

 
  for (j in 1:(N+1)){
    meanvars[j]   <- mean(vars[,j])
    medianvars[j] <- median(vars[,j])
    sdvars[j]     <- sd(vars[,j])
    skewvars[j]   <- skewness(vars[,j])
    kurtvars[j]   <- kurtosis(vars[,j])
    autocorrvars[j] <- cor(vars[2:tt,j], vars[1:(tt-1),j])

  }
 
   
  meanvars[1] <- meanvars[1] *52 *100 		# (Annualized Percentage Mean)
  medianvars[1] <- medianvars[1]*52 * 100  	# (Annualized Percentage Median)
  sdvars[1] <- sdvars[1] * sqrt(52) * 100  	# (Annualized Percentage Stdev)
   
  print(t(cbind(round(meanvars, digits=3) , round(medianvars, digits=3), round(sdvars, digits=3), round(skewvars, digits=3), round(kurtvars, digits=3), round(autocorrvars, digits=3) )))
    
   
   
   
   
   
   
   
   
   
   
   
   