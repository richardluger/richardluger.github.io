#**********************************************************************************
#   "Exact Inference in Long-Horizon Predictive Quantile Regressions with an Application to Stock Returns"
#    Journal of Financial Econometrics

# (C) Sermin Gungor (UWO  and Bank of Canada) and Richard Luger (Laval University)
#     sgungor@uwo.ca & richard.luger@fsa.ulaval.ca
  
#**********************************************************************************

# Description:
#   File: Table10-11+Table9_CI_Monthly   
#   This code produces:
#     -- LMC tests (Table 10), 
#	    -- MMC tests (Table 11),
#     -- Confidence Intervals for persistence parameter of the predictor variable in Table 9

# There are two ways to run this code (see MMC test section below):
   
#   -- For predictors to be restricted to stationarity.
#	-- For unrestricted predictors (allows for unit root or explosive predictors)
	  
#   Period: Jan 1962 -- Dec 2015

# WARNING: It can take a long time to compute the MMC tests. 
# The computation time depends on the number of MC replications ('totsim') and the fineness ('inc') of the grid over which the p-value is maximized.
# Note also that the MMC procedure yields randomized p-values.

#**********************************************************************************;

rm(list=ls())  

library(MASS)  
library(mvtnorm)
library(quantreg)

#########################################################################################################################################################
## Functions

ranklex <- function(x,uu) {
	n  <- length(x)
	vv <- cbind(x,uu) 
	r  <- matrix(0, n-1, 1)
	stat <- vv[n,]
	r[ stat[1] > vv[1:(n-1),1] ] <- 1
	r[ (stat[1] == vv[1:(n-1),1]) & (stat[2] > vv[1:(n-1),2]) ] <- 1
	sum(r)+1
}



sign01 <- function(z){
	z <- matrix(z,length(z),1)
	return(as.numeric(z >= 0))
}


	
MCpvalues <- function(phiH0, uhatH0, ehatH0){	
					
	statsLADphi <- matrix(0, totsim, 1)

	statsSarray <- array(0, dim=c(numHoriz+1, numTaus+1 ,totsim))


	statsLADphi[totsim] <-	(phihatDATALAD-phiH0)^2 / vhatDATALAD
	
	statsSarray[,,totsim] <- SallDATA


	for (isim in 1:(totsim-1)){
	
			perm <- sample(Tsize-1, replace=FALSE)
	
			rsim <- rDATA
			xsim <- xDATA

			for (t in 2:Tsize){
				rsim[t] <- 						 +  uhatH0[perm[t-1]]  				
		    	xsim[t] <-  phiH0  *  xsim[t-1]  +  ehatH0[perm[t-1]]
			}
				
			r <- rsim
			x <- xsim
			
			rhsim <- rhDATA
			xhsim <- xhDATA
					
			### Long horizons
      	
			j <- 1
			for (h in (HH-1)){
          
				for (t in 1:(Tsize-h)){
		
					rhsim[t,j] <- sum(r[t:(t+h)])		

					xhsim[t,j] <- x[t]
				}
				
				j <- j + 1		
			}		
			
			rh <- rhsim
			xh <- xhsim

			QRtstats <- matrix(0, numHoriz ,numTaus)
      
      		for (i in 1:numHoriz){

				j <- 1
				for (tau in Taus){
	
					temp <- rq(rh[2:Tsizeh[i],i]~xh[1:(Tsizeh[i]-1),i], tau=tau)
				
					QRtstats[i,j] <- as.numeric(summary(temp, se="iid")$coef[,"t value"][2])
					
					j <- j + 1
				}
			}	


			## Test statistics
		
			Stemp <- matrix(0, numHoriz+1, numTaus+1)

			Stemp[1:numHoriz, 1: numTaus] <- QRtstats^2


			for (i in 1:numHoriz){
		
				Stemp[i, numTaus+1]	<- max( Stemp[i, 1:numTaus] )
				
			}

			for (j in 1:(numTaus+1)){

				Stemp[numHoriz+1,j] <- max( Stemp[1:numHoriz,j] )
		
			}
	
			statsSarray[,,isim] <- Stemp

			## LAD for predictor variable

			YY <- matrix( x[2:Tsize], Tsize-1, 1 )
			X  <- matrix( x[1:(Tsize-1)], Tsize-1, 1)
			XX <- cbind(ones, X)

			temp <- rq(YY~X,tau=0.5)				
			phihat <- as.numeric( summary(temp, se="iid")$coef[,"Value"][2] )	
			vhat   <- as.numeric( summary(temp, se="iid")$coef[,"Std. Error"][2] )^2						
									
			statsLADphi[isim] <- (phihat-phiH0)^2 / vhat
						
	}

    uu <- runif(totsim)		

   	temp <- ranklex(statsLADphi,uu)     
    Xpvalue <- (totsim - temp + 1)/totsim        	
	
	Spvalues <- matrix(0, numHoriz+1, numTaus+1)

	for (i in 1:(numHoriz+1)){		
		for (j in 1:(numTaus+1)){
			    uu <- runif(totsim)			
			    temp <- ranklex(statsSarray[i,j,],uu)      
				Spvalues[i,j] <- (totsim - temp + 1)/totsim    					
		}
	}


	return( list( Spvalues= Spvalues, Xpvalue= Xpvalue ) )
		        
} 






#########################################################################################################################################################
#########################################################################################################################################################


### Long horizons >= 1

HH <- c(1,3, 12, 60, 120)
numHoriz <- length(HH)


## Quantiles

Taus    <- c( 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95 )

numTaus <- length(Taus) 



#########################################################################################################################################################
#########################################################################################################################################################
## DATA



  dataa <- read.table("Data_Used_Monthly_Jan1962_Dec2015.csv", header = TRUE, sep = ",")      # Data Period: Jan 1962 -- Dec 2015)

  datee    <- dataa$Dates
  xret     <- dataa$Xret_SPvw       # excess returns
  logxret  <- log(xret + 1)  		# log excess returns
  dp       <- dataa$d.p      		# log dividend/price
  ep       <- dataa$e.p       		# log earnings/price
  bm       <- dataa$b.m       		# book-to-market
  dfy      <- dataa$dfy       		# default yield
  tms      <- dataa$tms       		# term spread
  tbl      <- dataa$tbl       		# short rate
  
  ret      <- xret + (tbl/12)     	# Return

  Tsize <- tt <- length(datee)
  
  superXDATA <- cbind(dp, ep, bm, dfy, tms, tbl)
  numVars  <- length(superXDATA[1,])



stats_tsq <- array( 0, dim=c(numHoriz, numTaus, numVars) )

stats_LMC <- array(0, dim=c(numHoriz+1, numTaus+1 ,numVars))

stats_MMC <- array(0, dim=c(numHoriz+1, numTaus+1 ,numVars))


##################################################
 for (l in 1:numVars) {
     
	r <- xret
	x <- superXDATA[1:Tsize,l]
			
	rDATA <- r
	xDATA <- x
	#########################################################################################################################################################
	### Long horizons

	
	rh <- matrix(0, Tsize, numHoriz)

	xh <- matrix(0, Tsize, numHoriz)
	
	
	Tsizeh <- matrix(0, numHoriz, 1)


	j <- 1
	for (h in (HH-1)){

		for (t in 1:(Tsize-h)){
		
			rh[t,j] <- sum(r[t:(t+h)])		

			xh[t,j] <- x[t]
		}
		
		Tsizeh[j] <- Tsize-h
		
		j <- j + 1		
	}	
			
	rhDATA <- rh
	xhDATA <- xh
 

	
	###
	#########################################################################################################################################################



	#########################################################################################################################################################
	## Quantile predicitve regressions

	#########################################################################################################################################################
	

	QRtstats <- matrix(0, numHoriz ,numTaus)
	
	
	for (i in 1:numHoriz){

		j <- 1
		for (tau in Taus){
	
			temp <- rq(rh[2:Tsizeh[i],i]~xh[1:(Tsizeh[i]-1),i], tau=tau)
				
			QRtstats[i,j] <- as.numeric(summary(temp, se="iid")$coef[,"t value"][2])
				
			tstatsq <- QRtstats[i,j]^2
					
			pval  <-  1-pchisq( tstatsq, df=1) 

			stats_tsq[i, j, l] <- pval
	
			j <- j + 1
		}
	}	
    

   
	## Test statistics

	## All quantiles
	
	Sall <- matrix(0, numHoriz+1, numTaus+1)
	
	Sall[1:numHoriz, 1: numTaus] <- QRtstats^2

	for (i in 1:numHoriz){
		
		Sall[i, numTaus+1]	<- max(Sall[i,1:numTaus])
		
	}


	for (j in 1:(numTaus+1)){

		Sall[numHoriz+1,j] <- max(Sall[1:numHoriz,j])
		
	}

	SallDATA <- Sall
 

	#########################################################################################################################################################

  ## LAD regression for predictor variable

	YYDATA <- YY <- matrix( x[2:Tsize], Tsize-1, 1)
	XDATA  <- X  <- matrix( x[1:(Tsize-1)], Tsize-1, 1)

	ones <- matrix(1,Tsize-1,1)
	XXDATA <- XX <- cbind(ones, X)

	temp <- rq(YY~X, tau=0.5)				
 
  	phihatLAD <- as.numeric( summary(temp, se="iid")$coef[,"Value"][2] )
  	vhatLAD   <- as.numeric( summary(temp, se="iid")$coef[,"Std. Error"][2] )^2	

 
	phihatDATALAD <- phihatLAD
	vhatDATALAD <- vhatLAD


#########################################################################################################################################################
	

	alphatest  <- 0.05
	alphatest1 <- 0.01
	alphatest2 <- 0.04

	totsim <- 100
  
#########################################################################################################################################################
 
  
  ## LMC tests 

	## Using LAD point estimate
		
	YY <- YYDATA
	XX <- XXDATA
	X  <- XDATA

	phiH0 <- phihatDATALAD
	
	

	YYstar <- YY - phiH0 * X

	uhatH0 <- rDATA[2:Tsize]
	ehatH0 <- YYstar

	
	temp <- MCpvalues(phiH0, uhatH0, ehatH0)

    
	# All quantiles
	
	for (i in 1:(numHoriz+1)){
		for (j in 1:(numTaus+1)){
		
			stats_LMC[i,j,l] <- temp$Spvalues[i,j]
			
		}			
	}



# beginning of MMC test procedure

	#########################################################################################################################################################
	## MMC tests 


	lowerLAD <- phihatDATALAD - 6*sqrt(vhatDATALAD)
	upperLAD <- phihatDATALAD + 6*sqrt(vhatDATALAD)

#########################################################################################################################################################

  # Stationary Predictors  (Comment this out if you wish to allow for non-statonary predictors)
  
#  if(lowerLAD <= -1) {lower <- -0.999} else
#  {lower <- lowerLAD}
 
 
#  if(upperLAD >= 1) {upper <- 0.999} else
#  {upper <- upperLAD}

	#########################################################################################################################################################
  #Nonstationarity allowed  (Comment this out if you wish to restrict predictors to be stationary)
  
    lower <- lowerLAD
    upper <- upperLAD
    
#########################################################################################################################################################
	  
     
     
    if (identical(xDATA,dp)) {inc <- 0.0005}   else
    if (identical(xDATA,ep)) {inc <- 0.0007}   else
    if (identical(xDATA, bm)) {inc <- 0.0004}  else
    if (identical(xDATA, dfy)) {inc <- 0.001}  else
    if (identical(xDATA,tms)) {inc <- 0.001}   else
    if (identical(xDATA,tbl)) {inc <- 0.00015} 
      
	DD <- seq( lower, upper,  by=inc )
    
	totDD <- length(DD)
 
	Spvalues <- array(0, dim=c(numHoriz+1, numTaus+1 ,totDD))
	Xpvalues <- matrix(0, totDD, 1)

	j <- 1
	for (phiH0 in DD){
	
		YY <- YYDATA
		XX <- XXDATA
		X  <- XDATA

		YYstar <- YY - phiH0 * X

		uhatH0 <- rDATA[2:Tsize]
		ehatH0 <- YYstar
				    
		temp <- MCpvalues(phiH0, uhatH0, ehatH0)
		
		Spvalues[,,j] <- temp$Spvalues
		Xpvalues[j] <- temp$Xpvalue
	
		j <- j+1

	}


	idx <- Xpvalues > alphatest1


  	print("Confidence Interval ------")
	CI  <- DD[idx]
  	print(c(min(CI), max(CI)))             # Confidence interval for AR(1) parameter
     
	# All quantiles
	
	for (i in 1:(numHoriz+1)){
		for (j in 1:(numTaus+1)){

		stats_MMC[i,j,l] <- max( Spvalues[i,j,idx])	
			
		}			
	}

  }
  
  
  
  print('t-test ----------------------')
  print(stats_tsq)
  
  print('LMC ----------------------')
  print(stats_LMC)
  
  print('MMC ----------------------')
  print(stats_MMC)
  





