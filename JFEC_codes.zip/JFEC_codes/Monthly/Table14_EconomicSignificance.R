#**********************************************************************************
#   "Exact Inference in Long-Horizon Predictive Quantile Regressions with an Application to Stock Returns"
#    Journal of Financial Econometrics

# (C) Sermin Gungor (UWO  and Bank of Canada) and Richard Luger (Laval University)
#     sgungor@uwo.ca & richard.luger@fsa.ulaval.ca

#**********************************************************************************

# Description:
#   File: Table14_EconomicSignificance      
#   This code produces the estimates and statistics in Table 4
#   Period: Jan 1962 -- Dec 2015

#**********************************************************************************;


rm(list=ls())  ## clear the workspace
library(MASS)  
library(mvtnorm)
library(quantreg)



#################################################################################################
#################################################################################################
#                               DATA
#################################################################################################
#################################################################################################


  dataa <- read.table("Data_Used_Monthly_Jan1962_Dec2015.csv", header = TRUE, sep = ",")      # Data Period: Jan 1962 -- Dec 2015)


  datee    <- dataa$Dates
  xret     <- dataa$Xret_SPvw   # excess returns
  logxret  <- log(xret + 1)   	# log excess returns
  dp       <- dataa$d.p       	# log dividend/price
  ep       <- dataa$e.p       	# log earnings/price
  bm       <- dataa$b.m       	# book-to-market
  dfy      <- dataa$dfy       	# default yield
  tms      <- dataa$tms       	# term spread
  tbl      <- dataa$tbl       	# short rate


  tt    <- length(datee)
  N     <- 6

  Tsize <- tt


  # Determine the variables

   rDATA <- xret
   r     <- rDATA

#########################################################################################################################################################


#########################################################################################################################################################
	## Quantile predicitve regressions

 
 tauss  <- c(0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95) 
 numTaus <- length(tauss) 

 HH <- c(1,3,12,60,120)
 numHoriz <- length(HH)


 superXDATA <- cbind(dp, ep, bm, dfy, tms, tbl) 
 numVars  <- length(superXDATA[1,])
  
  

 QRInt <- array( 0, dim=c( numHoriz, numTaus, numVars) )
 QRIntsd <- array( 0, dim=c( numHoriz, numTaus, numVars) )
 QRparam <- array( 0, dim=c( numHoriz, numTaus, numVars) )
 QRparamsd <- array( 0, dim=c( numHoriz, numTaus, numVars) )
 QRtstats <- array( 0, dim=c( numHoriz, numTaus, numVars) )
 R1       <- array( 0, dim=c( numHoriz, numTaus, numVars) )
 ES       <- array( 0, dim=c( numHoriz, numTaus, numVars) )    
 stdev    <- array( 0, dim=c( numHoriz, numTaus, numVars) )
 
  for (l in 1:numVars) {
          
	r <- xret
	x <- superXDATA[1:Tsize,l]

	rDATA <- r
	xDATA <- x

 ### Long horizons

	
	rh <- matrix(0, Tsize, numHoriz)

	xh <- matrix(0, Tsize, numHoriz)
	
	
	Tsizeh <- matrix(0, numHoriz, 1)


	j <- 1
	for (h in (HH-1)){

		for (t in 1:(Tsize-h)){
		
			rh[t,j] <- sum(r[t:(t+h)])		

			xh[t,j] <- x[t]
		}
		
		Tsizeh[j] <- Tsize-h
		
		j <- j + 1		
	}	
			
	rhDATA <- rh
	xhDATA <- xh
 
	#########################################################################################################################################################
	## Quantile predictive regressions
	#########################################################################################################################################################

	for (i in 1:numHoriz){

		j <- 1
		for (tau in tauss){
	
			temp <- rq(rh[2:Tsizeh[i],i]~xh[1:(Tsizeh[i]-1),i], tau=tau)
			
    		QRInt[i,j,l] <- as.numeric( summary(temp, se="iid")$coef[,"Value"][1] )
		    QRIntsd[i,j,l] <- as.numeric( summary(temp, se="iid")$coef[,"Std. Error"][1] )
		  	QRparam[i,j,l] <- as.numeric( summary(temp, se="iid")$coef[,"Value"][2] )	
		    QRparamsd[i,j,l] <- as.numeric( summary(temp, se="iid")$coef[,"Std. Error"][2] )
	  	    QRtstats[i,j,l] <- as.numeric(summary(temp, se="iid")$coef[,"t value"][2])


		    fit0 <- rq(rh[2:Tsizeh[i],i]~1,tau=tau)
		    fit1 <- rq(rh[2:Tsizeh[i],i]~xh[1:(Tsizeh[i]-1),i], tau=tau)

		    rho <- function(u,tau=tau)u*(tau - (u < 0))
		    R1[i,j,l] <- 1 - fit1$rho/fit0$rho
	 
		   # Economic Significance
     
		    stdev_temp  <-  sd(as.numeric( summary(temp, se="iid")$coef[,"Value"][2] )	*xh[1:(Tsizeh[i]-1),i]) 
     
		    stdev[i,j,l] <- stdev_temp
     
		    ES[i,j,l] <-  stdev_temp / abs(quantile(rh[2:Tsizeh[i],i], tau))

		    j <- j + 1
   
		}
	}	
    
 
  }
 
 
 
 
 
#################################################################################################
#################################################################################################

  print("Unconditional Excess Returns -----------")
  print(quantile(xret ,tauss)*100)       #(percentage return)
  
  
 #################################################################################################
################################################################################################# 
  
  print("---------------------------")
  print("DIVIDEND/PRICE ------------")
  print("---------------------------")
 

 	print(rbind(   t(round(QRparam[1,,1], digits = 3)),   # Beta_1(tau)
        t(round(R1[1,,1]*100, digits=3)),               # R2(tau): Koenker and Machado (1999) goodness-of-fit measure, percent                                 
        t(round(stdev[1,,1]*100, digits=3)),            # Standard Dev. of Conditional Quantile (percent)
        t(round(ES[1,,1]*100, digits=3))    ))          # Economic Significance (percent)



#################################################################################################
#################################################################################################



  print("---------------------------")
  print("EARNINGS/PRICE ------------")
  print("---------------------------")
 

 	print(rbind(   t(round(QRparam[1,,2], digits = 3)),   # Beta_1(tau)
        t(round(R1[1,,2]*100, digits=3)),               # R2(tau): Koenker and Machado (1999) goodness-of-fit measure, percent                                 
        t(round(stdev[1,,2]*100, digits=3)),            # Standard Dev. of Conditional Quantile (percent)
        t(round(ES[1,,2]*100, digits=3))    ))          # Economic Significance (percent)

  
#################################################################################################
#################################################################################################



  print("---------------------------")
  print("BOOK VALUE/MARKET VALUE ------------")
  print("---------------------------")
 

 	print(rbind(   t(round(QRparam[1,,3], digits = 3)),   # Beta_1(tau)
        t(round(R1[1,,3]*100, digits=3)),               # R2(tau): Koenker and Machado (1999) goodness-of-fit measure, percent                                 
        t(round(stdev[1,,3]*100, digits=3)),            # Standard Dev. of Conditional Quantile (percent)
        t(round(ES[1,,3]*100, digits=3))    ))          # Economic Significance (percent)


#################################################################################################
#################################################################################################



  print("---------------------------")
  print("DEFAULT YIELD ------------")
  print("---------------------------")
 

 	print(rbind(   t(round(QRparam[1,,4], digits = 3)),   # Beta_1(tau)
        t(round(R1[1,,4]*100, digits=3)),               # R2(tau): Koenker and Machado (1999) goodness-of-fit measure, percent                                 
        t(round(stdev[1,,4]*100, digits=3)),            # Standard Dev. of Conditional Quantile (percent)
        t(round(ES[1,,4]*100, digits=3))    ))          # Economic Significance (percent)



#################################################################################################
#################################################################################################



  print("---------------------------")
  print("TERM SPREAD ------------")
  print("---------------------------")
 

 	print(rbind(   t(round(QRparam[1,,5], digits = 3)),   # Beta_1(tau)
        t(round(R1[1,,5]*100, digits=3)),               # R2(tau): Koenker and Machado (1999) goodness-of-fit measure, percent                                 
        t(round(stdev[1,,5]*100, digits=3)),            # Standard Dev. of Conditional Quantile (percent)
        t(round(ES[1,,5]*100, digits=3))    ))          # Economic Significance (percent)



#################################################################################################
#################################################################################################



  print("---------------------------")
  print("SHORT RATE ------------")
  print("---------------------------")
 

 	print(rbind(   t(round(QRparam[1,,6], digits = 3)),   # Beta_1(tau)
        t(round(R1[1,,6]*100, digits=3)),               # R2(tau): Koenker and Machado (1999) goodness-of-fit measure, percent                                 
        t(round(stdev[1,,6]*100, digits=3)),            # Standard Dev. of Conditional Quantile (percent)
        t(round(ES[1,,6]*100, digits=3))    ))          # Economic Significance (percent)
