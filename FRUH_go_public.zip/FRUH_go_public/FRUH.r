###
### Program accompanying the paper "Multiple testing of the forward rate unbiasedness hypothesis across currencies," by Hsuan Fu and Richard Luger 
### This R code reproduces the empirical results reported in Table 7 
### If you have any questions, please contact Richard Luger by email at richard.luger@fsa.ulaval.ca 
###


# Clear the workspace

rm(list=ls())  


####################################################################################################################################################
### Part 1. Functions



# Sign function that equals 1 if z >= 0, and zero otherwise

	Sign01 <- function(z){				
		z <- matrix(z,length(z),1)
		return(as.numeric(z >= 0))
	}



# Function that computes the lexicographic (i.e., tie-breaking) rank of the last element of x

	RankLex <- function(x,uu) {
		n  <- length(x)
		vv <- cbind(x,uu) 
		r  <- matrix(0, n-1, 1)
		stat <- vv[n,]
		r[ stat[1] > vv[1:(n-1),1] ] <- 1
		r[ (stat[1] == vv[1:(n-1),1]) & (stat[2] > vv[1:(n-1),2]) ] <- 1
		1+sum(r)
	}



# Function that computes the combined p-values (see Section 2.2) and multiplicity adjusted p-values (see Section 2.3) of the sign and Wilcoxon statistics, defined in Equations (11) and (13), respectively

	SignedRankTests <- function(Spots, Forwards, Levels=TRUE, Diffs=FALSE, TotSim){
		
		S <- matrix(0,N,1)
		W <- matrix(0,N,1)

		for (i in 1:N){
						
			s <- Spots[,i]
			f <- Forwards[,i]
							
			start <- startDates[i]
			end   <- endDates[i]
			
			if (Levels == TRUE){									
				y <- s[(start+1):end]
				x <- f[start:(end-1)] 				
			}	
			
			if (Diffs == TRUE){									
				y <- s[(start+1):end] - s[start:(end-1)]
				x <- f[start:(end-1)] - s[start:(end-1)]				
			}	
			
			TT <- length(y)
						
			S[i] <- sum( Sign01( (y-x)*x ) )
			S[i] <- ( S[i] - TT/2 )/sqrt(TT/4)

			ranks <- matrix(rank(abs(y-x)),TT,1)
			mW <- TT*(TT+1)/4
			vW <- TT*(TT+1)*(2*TT+1)/24
				
			W[i] <- sum( Sign01( (y-x)*x )*ranks )
			W[i] <- ( W[i] - mW )/sqrt(vW)												
		}
		
		pvaluesS <- 2*( 1-pnorm(abs(S)) )    # two-sided p-values
	    pvaluesW <- 2*( 1-pnorm(abs(W)) )    
	            
        minS <- min(pvaluesS)
	    prodS <- prod(pvaluesS)

		minW <- min(pvaluesW)
		prodW <- prod(pvaluesW)
		
		
		GlobalStats <- matrix(0, TotSim, 4)
		
		GlobalStats[TotSim,] <- c(minS, prodS, minW, prodW)
		
		SingleStep_S <- matrix(0, TotSim, N)
		SingleStep_W <- matrix(0, TotSim, N)

		SingleStep_S[TotSim,] <- pvaluesS
		SingleStep_W[TotSim,] <- pvaluesW


		temp <- sort(pvaluesS, decreasing=FALSE, index.return = TRUE)        				        				      				
		Sstats <- matrix(0, TotSim, N)
		Sstats[TotSim,] <- temp$x				
		Sindex <- temp$ix	
		Sqmins <- matrix(0, N, 1)


		temp <- sort(pvaluesW, decreasing=FALSE, index.return = TRUE)        				        				      				
		Wstats <- matrix(0, TotSim, N)
		Wstats[TotSim,] <- temp$x				
		Windex <- temp$ix	
		Wqmins <- matrix(0, N, 1)

		
		Y <- Spots[2:Tsize,]								
		X <- Forwards[1:(Tsize-1),]				
		B0 <- diag(1, N, N)		
		ehat <- Y - X %*% B0
		
		for (isim in 1:(TotSim-1)){
			
			ss <- sign(rnorm(Tsize-1))
				
			ehatsim <- ss * ehat
			
			for (i in 1:N){
			
				s <- Spots[,i]
				f <- Forwards[,i]
			
				start <- startDates[i]
				end   <- endDates[i]

				if (Levels == TRUE){									
					y <- s[(start+1):end]
					x <- f[start:(end-1)] 				
				}	
			
				if (Diffs == TRUE){									
					y <- s[(start+1):end] - s[start:(end-1)]
					x <- f[start:(end-1)] - s[start:(end-1)]				
				}	
	
				TT <- length(y)
				
				etil <- ehatsim[start:(end-1),i]
						
				S[i] <- sum( Sign01( etil*x ) )					
				S[i] <- ( S[i] - TT/2 )/sqrt(TT/4)

				ranks <- matrix(rank(abs(etil)),TT,1)
				mW <- TT*(TT+1)/4
				vW <- TT*(TT+1)*(2*TT+1)/24
				
				W[i] <- sum( Sign01( etil*x )*ranks )
				W[i] <- ( W[i] - mW )/sqrt(vW)
			}
		
			pvaluesS <- 2*( 1-pnorm(abs(S)) )    # two-sided p-values
        	pvaluesW <- 2*( 1-pnorm(abs(W)) )    
        
   	    	minS <- min(pvaluesS)
	    	prodS <- prod(pvaluesS)

			minW <- min(pvaluesW)
			prodW <- prod(pvaluesW)
			
			GlobalStats[isim,] <- c(minS, prodS, minW, prodW)
			
			SingleStep_S[isim,] <- minS
			SingleStep_W[isim,] <- minW
			
			Sqmins[N] <- pvaluesS[Sindex[N]]		
			for (i in (N-1):1) Sqmins[i] <- min( Sqmins[i+1], pvaluesS[Sindex[i]] )							
			Sstats[isim,] <- Sqmins		

			Wqmins[N] <- pvaluesW[Windex[N]]		
			for (i in (N-1):1) Wqmins[i] <- min( Wqmins[i+1], pvaluesW[Windex[i]] )							
			Wstats[isim,] <- Wqmins			
			
		}	
			
			
		u <- runif(TotSim)

	    PvalueMinS  <- RankLex(GlobalStats[,1],u)/TotSim
	    PvalueProdS <- RankLex(GlobalStats[,2],u)/TotSim
	    PvalueMinW  <- RankLex(GlobalStats[,3],u)/TotSim
	    PvalueProdW <- RankLex(GlobalStats[,4],u)/TotSim
	    	    	    
		SingleStep_AdjustedPvalues_S <- matrix(0, 1, N)
		SingleStep_AdjustedPvalues_W <- matrix(0, 1, N)
		
		for (i in 1:N){
		    SingleStep_AdjustedPvalues_S[i] <- RankLex(SingleStep_S[,i],u)/TotSim
		    SingleStep_AdjustedPvalues_W[i] <- RankLex(SingleStep_W[,i],u)/TotSim		    
		}    



		OrderedPvalues <- matrix(0, N, 1)

		for (j in 1:N) OrderedPvalues[j] <- RankLex(Sstats[,j],u)/TotSim    		

		for (j in 2:N) OrderedPvalues[j] <- max(OrderedPvalues[j-1], OrderedPvalues[j])   		

		StepDown_AdjustedPvalues_S <- matrix(0, N, 1)

		for (j in 1:N) StepDown_AdjustedPvalues_S[Sindex[j]] <- OrderedPvalues[j]



		OrderedPvalues <- matrix(0, N, 1)

		for (j in 1:N) OrderedPvalues[j] <- RankLex(Wstats[,j],u)/TotSim    		

		for (j in 2:N) OrderedPvalues[j] <- max(OrderedPvalues[j-1], OrderedPvalues[j])   		

		StepDown_AdjustedPvalues_W <- matrix(0, N, 1)

		for (j in 1:N) StepDown_AdjustedPvalues_W[Windex[j]] <- OrderedPvalues[j]



		return(list(PvalueMinS = PvalueMinS, PvalueProdS = PvalueProdS, PvalueMinW = PvalueMinW, PvalueProdW = PvalueProdW, SingleStep_AdjustedPvalues_S = SingleStep_AdjustedPvalues_S, SingleStep_AdjustedPvalues_W = SingleStep_AdjustedPvalues_W, StepDown_AdjustedPvalues_S = StepDown_AdjustedPvalues_S, StepDown_AdjustedPvalues_W = StepDown_AdjustedPvalues_W))
								
	}	









				
				
####################################################################################################################################################
### Part 2. Main program



data <- read.csv("data2.csv")

names(data)
dim(data)

for (j in 3:28){
		
	temp <- data[,j]
		
	idx <- ! is.na(temp)
	
	temp[idx] <- log(temp[idx])
	
	idx <- is.na(temp)
	
	temp[idx] <- 0
		
	data[,j] <- temp
	
}


# Put data in same order as in the paper

AUDUSD_s <- data$AUDUSD_s
AUDUSD_f <- data$AUDUSD_f

CADUSD_s <- data$CADUSD_s
CADUSD_f <- data$CADUSD_f

DKKUSD_s <- data$DKKUSD_s
DKKUSD_f <- data$DKKUSD_f

EURUSD_s <- data$EURUSD_s
EURUSD_f <- data$EURUSD_f

FRFUSD_s <- data$FRFUSD_s
FRFUSD_f <- data$FRFUSD_f

DEMUSD_s <- data$DEMUSD_s
DEMUSD_f <- data$DEMUSD_f

ITLUSD_s <- data$ITLUSD_s
ITLUSD_f <- data$ITLUSD_f

JPYUSD_s <- data$JPYUSD_s
JPYUSD_f <- data$JPYUSD_f

NZDUSD_s <- data$NZDUSD_s
NZDUSD_f <- data$NZDUSD_f

NOKUSD_s <- data$NOKUSD_s
NOKUSD_f <- data$NOKUSD_f

SEKUSD_s <- data$SEKUSD_s
SEKUSD_f <- data$SEKUSD_f

CHFUSD_s <- data$CHFUSD_s
CHFUSD_f <- data$CHFUSD_f

GBPUSD_s <- data$GBPUSD_s
GBPUSD_f <- data$GBPUSD_f



Spots    <- cbind(AUDUSD_s, CADUSD_s, CHFUSD_s, DEMUSD_s, DKKUSD_s, EURUSD_s, FRFUSD_s, GBPUSD_s, ITLUSD_s, JPYUSD_s, NOKUSD_s, NZDUSD_s, SEKUSD_s)
Forwards <- cbind(AUDUSD_f, CADUSD_f, CHFUSD_f, DEMUSD_f, DKKUSD_f, EURUSD_f, FRFUSD_f, GBPUSD_f, ITLUSD_f, JPYUSD_f, NOKUSD_f, NZDUSD_f, SEKUSD_f)

N <- 13

startDates <- endDates <- matrix(0, N, 1)

for (j in 1:N){
	
	temp <- Spots[,j]
	
	idx <- which(temp != 0)
	
	startDates[j] <- min(idx)
	
	endDates[j] <- max(idx)	
	
}


Tsize <- max(endDates)

codesS <- colnames(Spots)

codesF <- colnames(Forwards)




set.seed(123456)

# Levels

temp <- SignedRankTests(Spots, Forwards, Levels=TRUE, Diffs=FALSE, TotSim=1000)
print(temp)



# Differences

temp <- SignedRankTests(Spots, Forwards, Levels=FALSE, Diffs=TRUE, TotSim=1000)
print(temp)

	



